# Dashboard and mobile screenshots

Current UI captured with synthetic data. Dashboard: 1440×1000. Mobile web: 390×900.

Long screens include numbered scroll captures. Mobile images are browser renders of the React Native app, not physical-device captures.

## Dashboard

- [00-login.png](dashboard/00-login.png)
- [01-overview.png](dashboard/01-overview.png)
- [01-overview-scroll-01.png](dashboard/01-overview-scroll-01.png)
- [02-discharge-clearance.png](dashboard/02-discharge-clearance.png)
- [02-discharge-clearance-scroll-01.png](dashboard/02-discharge-clearance-scroll-01.png)
- [02b-discharge-pipeline.png](dashboard/02b-discharge-pipeline.png)
- [03-encounters-ledgers.png](dashboard/03-encounters-ledgers.png)
- [03b-pre-admission-estimator.png](dashboard/03b-pre-admission-estimator.png)
- [03b-pre-admission-estimator-scroll-01.png](dashboard/03b-pre-admission-estimator-scroll-01.png)
- [04-approvals-disputes.png](dashboard/04-approvals-disputes.png)
- [04b-hmo-gateway-roster.png](dashboard/04b-hmo-gateway-roster.png)
- [04b-hmo-gateway-roster-scroll-01.png](dashboard/04b-hmo-gateway-roster-scroll-01.png)
- [04c-disputes-promissory.png](dashboard/04c-disputes-promissory.png)
- [05-claims-esoa.png](dashboard/05-claims-esoa.png)
- [05-claims-esoa-scroll-01.png](dashboard/05-claims-esoa-scroll-01.png)
- [06-rcm-analytics.png](dashboard/06-rcm-analytics.png)
- [06-rcm-analytics-scroll-01.png](dashboard/06-rcm-analytics-scroll-01.png)
- [06-rcm-analytics-scroll-02.png](dashboard/06-rcm-analytics-scroll-02.png)
- [06-rcm-analytics-scroll-03.png](dashboard/06-rcm-analytics-scroll-03.png)
- [06-rcm-analytics-scroll-04.png](dashboard/06-rcm-analytics-scroll-04.png)
- [07-settings-rules.png](dashboard/07-settings-rules.png)
- [08-patient-portal.png](dashboard/08-patient-portal.png)

### SMS sandbox previews

All previews use the dedicated local synthetic fixture and deliver no cellular SMS.

- [Doctor nudge](dashboard/sms-sandbox/01-doctor-nudge.png)
- [QuickSign preview](dashboard/sms-sandbox/02-quicksign-preview.png)
- [Intake orientation](dashboard/sms-sandbox/03-intake-preview.png)
- [Admission preview](dashboard/sms-sandbox/04-admission-preview.png)

## Mobile

- [00-launch.png](mobile/00-launch.png)
- [01-onboarding-bill.png](mobile/01-onboarding-bill.png)
- [02-onboarding-coverage.png](mobile/02-onboarding-coverage.png)
- [03-onboarding-documents.png](mobile/03-onboarding-documents.png)
- [04-login.png](mobile/04-login.png)
- [05-create-account.png](mobile/05-create-account.png)
- [06-account-recovery.png](mobile/06-account-recovery.png)
- [07-home.png](mobile/07-home.png)
- [07-home-scroll-01.png](mobile/07-home-scroll-01.png)
- [08-bill.png](mobile/08-bill.png)
- [08-bill-scroll-01.png](mobile/08-bill-scroll-01.png)
- [09-coverage.png](mobile/09-coverage.png)
- [09-coverage-scroll-01.png](mobile/09-coverage-scroll-01.png)
- [10-payments.png](mobile/10-payments.png)
- [11-profile.png](mobile/11-profile.png)
- [11-profile-scroll-01.png](mobile/11-profile-scroll-01.png)
- [12-insurance-claims.png](mobile/12-insurance-claims.png)
- [13-documents.png](mobile/13-documents.png)
- [14-hospital-record.png](mobile/14-hospital-record.png)
- [14-hospital-record-scroll-01.png](mobile/14-hospital-record-scroll-01.png)
- [15-hospital-updates.png](mobile/15-hospital-updates.png)
- [16-cora-assistant.png](mobile/16-cora-assistant.png)
- [payment-flow/01-amount.png](mobile/payment-flow/01-amount.png)
- [payment-flow/02-methods.png](mobile/payment-flow/02-methods.png)
- [payment-flow/02-methods-scroll-01.png](mobile/payment-flow/02-methods-scroll-01.png)
- [payment-flow/03-qr-ph.png](mobile/payment-flow/03-qr-ph.png)
- [payment-flow/04-qr-review.png](mobile/payment-flow/04-qr-review.png)
- [payment-flow/05-processing.png](mobile/payment-flow/05-processing.png)
- [payment-flow/06-success.png](mobile/payment-flow/06-success.png)
- [payment-flow/07-receipt.png](mobile/payment-flow/07-receipt.png)
- [10b-payments-recorded.png](mobile/10b-payments-recorded.png)
- [payment-flow/08-gcash-details.png](mobile/payment-flow/08-gcash-details.png)
- [payment-flow/08-gcash-review.png](mobile/payment-flow/08-gcash-review.png)
- [payment-flow/09-maya-details.png](mobile/payment-flow/09-maya-details.png)
- [payment-flow/09-maya-review.png](mobile/payment-flow/09-maya-review.png)
- [payment-flow/10-card-details.png](mobile/payment-flow/10-card-details.png)
- [payment-flow/10-card-review.png](mobile/payment-flow/10-card-review.png)
- [payment-flow/11-bank-details.png](mobile/payment-flow/11-bank-details.png)
- [payment-flow/11-bank-review.png](mobile/payment-flow/11-bank-review.png)
- [payment-flow/12-payment-plan-details.png](mobile/payment-flow/12-payment-plan-details.png)
- [payment-flow/12-payment-plan-details-scroll-01.png](mobile/payment-flow/12-payment-plan-details-scroll-01.png)
- [payment-flow/12-payment-plan-review.png](mobile/payment-flow/12-payment-plan-review.png)
- [payment-flow/12-payment-plan-review-scroll-01.png](mobile/payment-flow/12-payment-plan-review-scroll-01.png)
- [payment-flow/13-payment-plan-recorded.png](mobile/payment-flow/13-payment-plan-recorded.png)
- [13b-documents-with-receipt.png](mobile/13b-documents-with-receipt.png)
- [17-historical-receipt.png](mobile/17-historical-receipt.png)
- [17-historical-receipt-scroll-01.png](mobile/17-historical-receipt-scroll-01.png)
- [17-historical-receipt-scroll-02.png](mobile/17-historical-receipt-scroll-02.png)

Reproduce with `node scripts/captureUiScreenshots.mjs` while the existing synthetic fixture and local previews are running. See `apps/mobile/validation/apple-ui/README.md` for startup commands.
